require("./all/module.js")

//========== Setting Owner ==========//
global.owner = "6283845460283" //ganti ke no lu
global.namaowner = "𝗖𝗹𝗮𝗿𝗮𝗫𝗩𝟭" //ganti ke nama lu

//======== Setting Bot & Link ========//
global.namabot = "𝗖𝗹𝗮𝗿𝗮𝗫𝗩𝟭 𝗖𝗥𝗔𝗦𝗛" // jgn diubah agar tidak error
global.namabot2 = "𝗖𝗹𝗮𝗿𝗮𝗫𝗩𝟭 𝗖𝗥𝗔𝗦𝗛" // jgn diubah agar tdak error
global.foother = "© Copyright ClaraXV1" // jgn diubah agar tdak error
global.idsaluran = "120363311617247434@newsletter" // ganti ke id ch lu
global.linkgc = 'https://chat.whatsapp.com/JQo1i4wluSs7U3aYXsCyDG' // ganti ke link gc lu
global.linksaluran = "https://whatsapp.com/channel/0029VamxW103WHTXJ6g2Z10g" // ganti ke link ch lu
global.linkyt = 'https://youtube.com/@cyawwww?si=IKhx8Iuh5azIvSy1t' // jgn diubah
global.linktele = "https://t.me/clara" // ganti ke link tele lu
global.packname = "Developed by ClaraXV1" // jgn diubah
global.author = "ClaraXV1" // jangan diubah

//========== Setting Event ==========//
global.welcome = false
global.autoread = false
global.anticall = false
global.owneroff = false

//==== Waktu Jeda Jpm & Pushkon ====//
global.delaypushkontak = 5500
global.delayjpm = 5500

//========= Setting Url Foto =========//
//Lihat Di Folder Media!

//========== Setting Panell ==========//
global.egg = "15"
global.loc = "1"
global.domain = "https://-"
global.apikey = "-"
global.capikey = "-"

//========= Setting Payment =========//
//Kalo Gak Ada Isi Aja jadi false
global.dana = 85182708258
global.gopay = false
global.ovo = false
global.seabank = 901840682958
global.linksaweria = false
global.qris = fs.readFileSync("./media/qris.jpg")
                             
//=========== Api Domain ===========//
global.zone1 = "-"
global.apitoken1 = "---"
global.tld1 = "-"

//========== Api Domain 2 ==========//
global.zone2 = "-";
global.apitoken2 = "-";
global.tld2 = "-";
//========== Api Domain 3 ==========//
global.zone3 = "-";
global.apitoken3 = "-";
global.tld3 = "-";
//========== Api Domain 4 ==========//
global.zone4 = "-";
global.apitoken4 = "-";
global.tld4 = "-";

//========= Setting Message =========//
global.msg = {
"error": "Error / terjadi kesalahan",
"done": "Done Kak 💞", 
"wait": "Bot Sedang Memproses . . .", 
"group": "*• Group Only* Fitur Ini Cuma Buat Di Dalam Grup!", 
"private": "*• Private Chat* Fitur Ini Cuma Buat Di Dalam Private Chat!", 
"admin": "*• Admin Only* Fitur Ini Cuma Buat Atmin!", 
"adminbot": "*• Bot Admin* Fitur Ini Cuma Bisa Dipake Kalo Bot Jadi Atmin", 
"owner": "*• Owner Only* Fitur Ini Cuma Buat Owner Bot!", 
"developer": "*• Developer Only* Fitur Ini Cuma Buat Developer!"
}


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})